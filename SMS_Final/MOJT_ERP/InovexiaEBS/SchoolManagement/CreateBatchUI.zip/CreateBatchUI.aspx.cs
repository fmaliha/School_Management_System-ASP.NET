﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using InovexiaEBS.BusinessEntity.SchoolManagement;
using InovexiaEBS.BusinessLogic.SchoolManagement;
using PBSConnLib;
using Telerik.Web.UI;

namespace InovexiaEBS.SchoolManagement
{
    public partial class CreateBatchUI : System.Web.UI.Page
    {
        private PBSDBUtility pb = new PBSDBUtility();
        protected void Page_Load(object sender, EventArgs e)
        {
              //BindDropdown();
            if (!IsPostBack)
            {

                
                //ddlyf();
            }
               
        }
        

        protected void ddlclass_ItemsRequested(object sender, RadComboBoxItemsRequestedEventArgs e)
        {
            try
            {
                DataTable DT = pb.GetDataByProc("SM_GetClassList");
                foreach (DataRow datarow in DT.Rows)
                {
                    RadComboBoxItem item = new RadComboBoxItem();
                    item.Text = (string)datarow["ClassName"];
                    item.Value = datarow["ClassID"].ToString();
                    item.Attributes.Add("ClassName", datarow["ClassName"].ToString());
                    ddlclass.Items.Add(item);
                    item.DataBind();
                }

            }
            catch (Exception)
            {

                throw;
            }
        }

        protected void ddlyear_ItemsRequested(object sender, RadComboBoxItemsRequestedEventArgs e)
        {
            try
            {
                //DataTable DT = pb.GetDataByProc("SM_GetClassList");
                //foreach (DataRow datarow in DT.Rows)
                //{
                //    RadComboBoxItem item = new RadComboBoxItem();
                //    item.Text = (string)datarow["ClassName"];
                //    item.Value = datarow["ClassID"].ToString();
                //    item.Attributes.Add("ClassName", datarow["ClassName"].ToString());
                //    ddlyear.Items.Add(item);
                //    item.DataBind();
                //}

            }
            catch (Exception)
            {

                throw;
            }
        }

        //void BindDropdown()
        //{
            

        //    var currentYear = DateTime.Today.Year;
        //    for (int i = 2; i >= 0; i--)
        //    {
        //        // Now just add an entry that's the current year minus the counter
        //        ddlyear.Items.Add(new RadComboBoxItem((currentYear - i).ToString("yyyy")));
        //    }
        //}


        protected void btnsavebatch_OnClick(object sender, EventArgs e)
        {
            VmStudentRegistration objbatch = new VmStudentRegistration();
            objbatch.batchname = txtbatchname.Text.Trim();
            objbatch.batchyearName = ddlyearf.Text.Trim();
            objbatch.classname = ddlclass.Text.Trim();
            objbatch.batchremarks = txtbatchremarks.Text.Trim();

           checkbatch(objbatch);
        }

        private void checkbatch(VmStudentRegistration objbatch)
        {
            try
            {
                Hashtable ht = new Hashtable();

                ht.Add("SectionName", objbatch.batchname);
                ht.Add("BatchYearName", objbatch.batchyearName);
                ht.Add("ClassName", objbatch.classname);


                DataTable dbt = CreateBatchBLL.checkbatchnames(ht);

                if (dbt != null)
                {
                    hfbatchcheck.Visible = true;

                    hfbatchcheck.Value = "This record already exists!";

                }
                else
                {
                    
                        CreateBatch(objbatch);
                   
                }
               
                
            }
            catch (Exception)
            {
                
                throw;
            }
          
        }

        private void CreateBatch(VmStudentRegistration objbatch)
        {

         try
            {
                long result = 1;
                //objbatch.batchname = txtbatchname.Text.Trim();
                //objbatch.batchyearName = ddlyearf.Text.Trim();
                //objbatch.classname = ddlclass.Text.Trim();
                //objbatch.batchremarks = txtbatchremarks.Text.Trim();

                result = CreateBatchBLL.SaveYearBatch(objbatch);
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message.ToString());
            }
        }

     
        protected void ddlyearf_ItemsRequested(object sender, RadComboBoxItemsRequestedEventArgs e)
        {
            ddlyearf.Items.Clear();
            
            var year = DateTime.Now.Year;
            for (int i = 2; i >= 0; i--)
            {
               //RadComboBoxItem item = new RadComboBoxItem(i.ToString());
              ////item.Text = year.ToString();
              //  //item.Value = year.ToString();
              //  //item.Attributes.Add(year.ToString(), year.ToString());
               ddlyearf.Items.Add(new RadComboBoxItem((year-1).ToString()));
               //item.DataBind();
                
               
                
            }
           // ddlyearf.Items.FindItemByValue(year.ToString()).Selected= true;

            
        }


        protected void ddlyeart_ItemsRequested(object sender, RadComboBoxItemsRequestedEventArgs e)
        {
            ddlyeart.Items.Clear();

          
            var year = DateTime.Now.Year;
            for (int i = 2; i >= 0; i--)
            {
                RadComboBoxItem a = new RadComboBoxItem((year-1).ToString());
                ddlyeart.Items.Add(a);
            }
        }
    }
}